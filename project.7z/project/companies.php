<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Register Consumer Complaint online in India - Hootzap</title>
    <meta name="description" content="Hootzap is a legal complaint service in India that resolves online consumer complaints and provides the right compensation . Register your complaint to solve your problem." />
    <meta name="author" content="RAWR">
    <?php include 'include/styles.php';?>
    <!-- Inline Css Here -->
    <style type="text/css"></style>
</head>

<body class="front preload">
    <!-- page wrapper start (Add "boxed" class to page-wrapper in order to enable boxed layout mode) -->
    <div class="page-wrapper">
        <!-- scrollToTop start -->
        <div class="scrollToTop"><i class="fa fa-angle-up"></i></div>
        <!-- scrollToTop end -->
        <?php include 'include/pre-header.php';?>
        <?php include 'include/header-top.php';?>
        <?php include 'include/header.php';?>
        <?php include 'include/nav.php';?>
        <?php include 'include/banner.php';?>
        <!-- ################################################
			 ########## MAIN CONTENT STARTS HERE! ###########
			 ################################################ -->
			<section class="main">

				<!-- page intro start -->
				<div class="page-intro">
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<h1 class="page-title">Portfolio - Full Width</h1>
							</div>
							<div class="col-md-6">
								<div class="breadcrumb-wrapper">
									<ol class="breadcrumb">
										<li><a href="#"><i class="fa fa-home"></i>Home</a></li>
										<li class="active">Portfolio</li>
									</ol>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- page intro end -->

				<!-- main content wrapper start -->
				<div class="main-content-wrapper">

					<!-- main content start -->
					<section class="main-content">
						<div class="container">
							<div class="row">
								<div class="col-md-12">
									<div class="filters">
										<ul class="nav nav-pills">
											<li class="active"><a href="#" data-filter="*">All</a></li>
											<li><a href="#" data-filter=".web-design">Web design</a></li>
											<li><a href="#" data-filter=".app-development">App development</a></li>
											<li><a href="#" data-filter=".site-building">Site building</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="img-boxes one-fourth isotope-container">
							<div class="img-box isotope-item web-design">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-1.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>Web Desing</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item app-development">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-2.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>App Development</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item web-design">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-3.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>Web Desing</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item site-building">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-4.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>Site Building</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item app-development">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-8.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>App Development</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item site-building">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-7.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>Site Building</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item app-development">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-6.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>App Development</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
							<div class="img-box isotope-item web-design site-building">
								<a href="portfolio-item.html" class="mask-wrapper">
									<img src="images/portfolio-5.jpg" alt="">
									<div class="mask">
										<p>Lorem ipsum dolor sit amet</p>
										<span>Web Design &amp; Site Building</span>
										<span class="triangle"><i class="fa fa-link"></i></span>
									</div>
								</a>
							</div>
						</div>
					</section>
        <!-- ################################################
			 ############ MAIN CONTENT ENDS HERE! ###########
			 ################################################  -->
        <?php include 'include/footer.php';?>
    </div>
    <!-- page wrapper end -->
    <?php include 'include/scripts.php';?>
    <!-- Inline javascript here! -->
    <script type="text/javascript">
    	
    </script>
</body>

</html>
