<!-- main-navigation start (remove fixed class from main-navigation in order to disable fixed navigation mode)-->
<div class="main-navigation header-style-2 fixed">
    <div class="container">
        <div class="row">

                <!-- navbar start -->
                <nav class="navbar navbar-default" role="navigation">
                    <!-- Toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-collapse-1">
                                    <ul class="nav navbar-nav navbar-main-menu">
                                        <li class="dropdown">
                                            <a href="index.php" class="dropdown-toggle" data-toggle="dropdown" >Home</a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="page-about.html" class="dropdown-toggle" data-toggle="dropdown" >About</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="page-about.html" style="color:white">About Us</a></li>
                                                <li><a href="page-team.html" style="color:white">Our Team</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="blog.php" class="dropdown-toggle" data-toggle="dropdown" >Blog</a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="Companies.php" class="dropdown-toggle" data-toggle="dropdown" >Companies</a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="contact.php" class="dropdown-toggle" data-toggle="dropdown" >Contact Us</a>
                                        </li>
                                    </ul>
                            <!-- <li class="dropdown">
											<a href="blog.html" class="dropdown-toggle" data-toggle="dropdown">Blog</a>
											<ul class="dropdown-menu">
												<li><a href="blog.html">Blog small images</a></li>
												<li><a href="blog-2.html">Blog large images</a></li>
												<li><a href="blog-no-sidebar.html">Blog - No Sidebars</a></li>
												<li><a href="blog-post.html">Blog post</a></li>
											</ul>
										</li>
										<li class="dropdown">
											<a href="portfolio-full.html" class="dropdown-toggle" data-toggle="dropdown">Portfolio</a>
											<ul class="dropdown-menu">
												<li class="dropdown">
													<a href="portfolio-full.html" class="dropdown-toggle" data-toggle="dropdown">Portfolio - Style 1</a>
													<ul class="dropdown-menu">
														<li><a href="portfolio-3col.html">Portfolio - 3 columns</a></li>
														<li><a href="portfolio-4col.html">Portfolio - 4 columns</a></li>
														<li><a href="portfolio-full.html">Portfolio - Full width</a></li>
														<li><a href="portfolio-sidebar.html">Portfolio - With sidebar</a></li>
													</ul>
												</li>
												<li class="dropdown">
													<a href="portfolio-3col-2.html" class="dropdown-toggle" data-toggle="dropdown">Portfolio - Style 2</a>
													<ul class="dropdown-menu">
														<li><a href="portfolio-3col-2.html">Portfolio - 3 columns</a></li>
														<li><a href="portfolio-4col-2.html">Portfolio - 4 columns</a></li>
														<li><a href="portfolio-sidebar-2.html">Portfolio - With sidebar</a></li>
													</ul>
												</li>
												<li><a href="portfolio-item.html">Portfolio single</a></li>
												<li><a href="portfolio-item-2.html">Portfolio single 2</a></li>
											</ul>
										</li>
										<li class="dropdown">
											<a href="features-shortcodes.html" class="dropdown-toggle" data-toggle="dropdown">Features</a>
											<ul class="dropdown-menu">
												<li><a href="features-typography.html">Typography</a></li>
												<li class="dropdown">
													<a href="features-shortcodes.html" class="dropdown-toggle" data-toggle="dropdown">Shortcodes</a>
													<ul class="dropdown-menu">
														<li><a href="features-shortcodes.html#tabs">Tabs</a></li>
														<li><a href="features-shortcodes.html#collapse">Accordion</a></li>
														<li><a href="features-shortcodes.html#social-icons">Social Icons</a></li>
														<li><a href="features-shortcodes.html#buttons">Buttons</a></li>
														<li><a href="features-shortcodes.html#progress-bars">Progress Bars</a></li>
														<li><a href="features-shortcodes.html#basic-slideshow">Basic Slideshow</a></li>
														<li><a href="features-shortcodes.html#icon-boxes">Icon Boxes</a></li>
														<li><a href="features-shortcodes.html#image-boxes">Images Boxes</a></li>
														<li><a href="features-shortcodes.html#animations">Animations</a></li>
														<li><a href="features-shortcodes.html#tables">Tables</a></li>
													</ul>
												</li>
												<li><a href="features-pricing-tables.html">Pricing tables</a></li>
												<li><a href="features-header-2.html">Alternative Header</a></li>
												<li><a href="features-footers.html">Footer Options</a></li>
											</ul>
										</li>
										<li class="dropdown">
											<a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages</a>
											<ul class="dropdown-menu">
												<li><a href="page-contact.html">Contact</a></li>
												<li><a href="page-team.html">Our team</a></li>
												<li><a href="page-services.html">Services</a></li>
												<li><a href="page-404.html">404 error</a></li>
												<li><a href="page-left-sidebar.html">Left Sidebar</a></li>
												<li><a href="page-right-sidebar.html">Right Sidebar</a></li>
												<li><a href="page-two-sidebars.html">Two Sidebars</a></li>
												<li><a href="page-no-sidebar.html">No Sidebars</a></li>
											</ul>
										</li> -->
                        </ul>
                        <ul class="nav navbar-nav navbar-right navbar-symbols" style="margin-right:50px">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-search"></i></a>
                                <ul class="dropdown-menu animated fadeInDownSmall">
                                    <li>
                                        <form role="search">
                                            <div class="form-group search" >
                                                <input type="text" class="form-control" placeholder="Search">
                                            </div>
                                        </form>
                                    </li>
                                </ul>
                                <div class="vertical-div hidden-xs"></div>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Login</a>
                                <ul class="dropdown-menu animated fadeInDownSmall">
                                    <li>
                                        <form class="login-form">
                                            <div class="form-group name">
                                                <input type="text" class="form-control" placeholder="username">
                                            </div>
                                            <div class="form-group password">
                                                <input type="text" class="form-control" placeholder="password">
                                            </div>
                                            <button type="submit" class="btn btn-gray">Log In</button>
                                            <span>or</span>
                                            <button type="submit" class="btn btn-gray btn-default">Sing Up</button>
                                            <ul>
                                                <li><a href="#">Forgot your password?</a></li>
                                            </ul>
                                            <div class="divider"></div>
                                            <span class="text-center">Login with</span>
                                            <a href="#" class="btn btn-symb btn-facebook"> <i class="fa fa-facebook"></i></a>
                                            <a href="#" class="btn btn-symb btn-twitter"> <i class="fa fa-twitter"></i></a>
                                            <a href="#" class="btn btn-symb btn-googleplus"> <i class="fa fa-google-plus"></i></a>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- navbar end -->
            </div>
        </div>
    </div>
</div>
<!-- main-navigation end -->
