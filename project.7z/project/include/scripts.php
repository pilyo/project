<!-- JavaScript files placed at the end of the document so the pages load faster
		================================================== -->
<!-- Jquery and Bootstap core js files -->
<script type="text/javascript" src="plugins/jquery.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<!-- Modernizr javascript -->
<script type="text/javascript" src="plugins/modernizr.js"></script>
<!-- Flexslider javascript -->
<script type="text/javascript" src="plugins/flexslider/jquery.flexslider.js"></script>
<!-- Owl carousel javascript -->
<script type="text/javascript" src="plugins/owl-carousel/owl.carousel.js"></script>
<!-- Magnific Popup javascript -->
<script type="text/javascript" src="plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
<!-- Appear javascript -->
<script type="text/javascript" src="plugins/jquery.appear.js"></script>
<!-- Count To javascript -->
<script type="text/javascript" src="plugins/jquery.countTo.js"></script>
<!-- Flowtype javascript -->
<script type="text/javascript" src="plugins/flowtype.js"></script>
<!-- Parallax javascript -->
<script src="plugins/jquery.parallax-1.1.3.js"></script>
<!-- Contact form -->
<script src="plugins/jquery.validate.js"></script>
<!-- Initialization of Plugins -->
<script type="text/javascript" src="js/template.js"></script>
