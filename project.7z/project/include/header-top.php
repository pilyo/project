<!-- header top start -->
<div class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <ul class="info">
                    <li><i class="fa fa-phone"></i> +91-11-39595933</li>
                    <li><i class="fa fa-envelope"></i> info@hootzap.com</li>
                </ul>
            </div>
            <div class="col-md-4">
                <ul class="social-links text-right">
                    <li><a target="_blank" href="http://www.facebook.com" style="background-color:#3262b9"><i class="fa fa-facebook"></i></a></li>
                    <li><a target="_blank" href="http://www.twitter.com" style="background-color:#29C5F6" ><i class="fa fa-twitter"></i></a></li>
                    <li><a target="_blank" href="http://plus.google.com" style="background-color:#de2020"><i class="fa fa-google-plus"></i></a></li>
                    <li><a target="_blank" href="http://www.skype.com" style="background-color:#3262b9"><i class="fa fa-skype"></i></a></li>
                    <li><a target="_blank" href="http://www.linkedin.com" style="background-color:#069"><i class="fa fa-linkedin"></i></a></li>
                    <li><a target="_blank" href="http://www.pinterest.com" style="background-color:#C61118"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- header top end -->
