<!-- header start -->
<header class="header text-center" style="background-color:#2e343a;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo">
                    <a href="index.php"><img id="logo" src="images/logo.png" alt="HootZap"></a>
                </div>

            </div>
        </div>
    </div>
</header>
<!-- header end -->
