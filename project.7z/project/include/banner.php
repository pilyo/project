
<!-- section start 
<div class="section pb-clear pt-clear">
   <div class="testimonials parallax">
      <!-- flexslider start 
      <div class="flexslider">
         <ul class="slides">
            <li clearfix>
               <div class="col-sm-6 slider_right">
                  <div class="col-sm-12 slider_caption">
                     <h4 style="padding-top:25%;font-size:27px;line-height:35px;font-style:italic;font-color:white;"> "Needed this since long. Iam glad things are changing. Great work done by the team and so pocket friendly" <span style="display:block;font-style:italic; font-size:14px"> --Jatin Chaudhary</span></h4>
                  </div>
               </div>
               <div class="col-sm-6"><img src="images/4.png" alt="File Consumer Complaints in India"/></div>
            </li>
            <li clearfix>
               <div class="col-sm-6 slider_right">
                  <div class="col-sm-12 slider_caption">
                     <h4 style="padding-top:25%;font-size:27px;line-height:35px;font-style:italic;font-color:white;">"The Idea itself is so great. It has made me stress free.
                        Now i know that if any purchase goes wrong. I can contact HootZap" <span style="display:block;font-style:italic; font-size:14px"> -- Leena Kholi</span>
                     </h4>
                  </div>
               </div>
               <div class="col-sm-6"><img src="images/9.png" alt="consumer complaints online"/></div>
            </li>
            <li clearfix>
               <div class="col-sm-6 slider_right">
                  <div class="col-sm-12 slider_caption">
                     <h4 style="padding-top:25%;font-size:27px;line-height:35px;font-style:italic;font-color:white;"> "Iam impressed by the service provided by HootZap.
                        They makes things so easy. Its my highest recommendation" <span style="display:block;font-style:italic; font-size:14px">  -- Amit Suneja </span>
                     </h4>
                  </div>
               </div>
               <div class="col-sm-6"><img src="images/6.png" alt="Post consumer complaints online at HootZap"/></div>
            </li>
         </ul>
      </div>
      <div class="clearfix"> </div>
      </section>
      </ul>
   </div>
   <!-- flexslider end
</div>
</div>
<!-- section end -->

