<!-- footer start -->
<footer>
    <!-- .footer start -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="footer-content">
                        <ul style="list-style:none">
                            <h2 style="font-color:#fff">The Company</h2>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Our Team</a></li>
                            <li><a href="#">Terms and conditions</a></li>
                            <li><a href="#">FAQS</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Refund Policy</a></li>

                            <h2 style="font-color:#fff">CONTACT US</h2>
                            <i class="fa fa-phone">    +91-11-39595933</i><br>
                            <i class="fa fa-envelope">     info@hootzap.com</i>

                            


                        </ul>

                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="footer-content">
                        <h2>Latest tweets</h2>
                        <ul class="tweets">
                            <li>
                                <i class="fa fa-twitter"></i>
                                <p><a href="#">@lorem</a> ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt <a href="#">http://t.co/dzLEYGeEH9</a>.</p><span>16 hours ago</span>
                            </li>
                            <li>
                                <i class="fa fa-twitter"></i>
                                <p><a href="#">@lorem</a> ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt <a href="#">http://t.co/dzLEYGeEH9</a>.</p><span>16 hours ago</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--
                <div class="col-sm-4">
                    <div class="footer-content">
                        <h2>Latest Projects</h2>
                        <div class="gallery row">
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-1.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-2.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-3.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-4.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-5.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-6.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-7.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-8.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                            <div class="gallery-item col-xs-4">
                                <a href="portfolio-item.html" class="mask-wrapper">
                                    <img src="images/gallery-9.jpg" alt="">
                                    <span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div> 
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!--Indicator
                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="single-review">
                                    <div class="review-text">
                                        <p>Lorem ipsum dolor sit amet, conssadipscing elitr, sed diam nonumy eirmod
                                            tempvidunt ut labore et dolore magna aliquyam erat,sed diam voluptua. At
                                            vero eos et accusam justo duo dolores et ea rebum.gubergren no sea takimata
                                            magna aliquyam eratma</p>
                                    </div>
                                    <div class="author-id">
                                        <img src="images/6.png" alt="" style="width:175px;height:175px">

                                        <div class="author-text">
                                            <h4>Sophia</h4>

                                            <h4>CEO, ReadyTheme</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="single-review">
                                    <div class="review-text">
                                        <p>Lorem ipsum dolor sit amet, conssadipscing elitr, sed diam nonumy eirmod
                                            tempvidunt ut labore et dolore magna aliquyam erat,sed diam voluptua. At
                                            vero eos et accusam justo duo dolores et ea rebum.gubergren no sea takimata
                                            magna aliquyam eratma</p>
                                    </div>
                                    <div class="author-id">
                                        <img src="images/4.png" alt="" style="width:175px;height:175px">

                                        <div class="author-text">
                                            <h4>Sophia</h4>

                                            <h4>CEO, ReadyTheme</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="single-review">
                                    <div class="review-text">
                                        <p>Lorem ipsum dolor sit amet, conssadipscing elitr, sed diam nonumy eirmod
                                            tempvidunt ut labore et dolore magna aliquyam erat,sed diam voluptua. At
                                            vero eos et accusam justo duo dolores et ea rebum.gubergren no sea takimata
                                            magna aliquyam eratma</p>
                                    </div>
                                    <div class="author-id">
                                        <img src="images/9.png" alt="" style="width:175px;height:175px">

                                        <div class="author-text">
                                            <h4>Sophia</h4>

                                            <h4>CEO, ReadyTheme</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
        -->
            </div>
        </div>
    </div>
    <!-- .footer end -->
    <!-- .subfooter start -->
    <div class="subfooter">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <center>
                    <p>Copyright © <?php echo date("Y"); ?> <a href="index.php">HootZap</a>  All Rights Reserved</p></center>
                </div>
            </div>
                <div class="col-md-8">
                    <nav class="navbar navbar-default" role="navigation">
                        <!-- Toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-2">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>

                    </nav>
                </div>

            </div>

        </div>
    </div>
    <!-- /.subfooter end -->
</footer>
<!-- footer end -->
