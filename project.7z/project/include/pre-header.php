<!-- preheader start -->
<div class="preheader">
    <div class="container">
        <div class="preheader-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="space hidden" id="preheader-contactSuccess">
                        <strong>Success!</strong> Your message has been sent to us.
                    </div>
                    <div class="space hidden" id="preheader-contactError">
                        <strong>Error!</strong> There was an error sending your message.
                    </div>
                    <h2>Drop us a line</h2>
                    <div class="row">
                        <form role="form" id="preheader-contact-form">
                            <div class="col-md-6">
                                <div class="form-group name">
                                    <label for="name3">Name*</label>
                                    <input type="text" class="form-control" id="name3" placeholder="" name="name3">
                                </div>
                                <div class="form-group email">
                                    <label for="email3">Email*</label>
                                    <input type="email" class="form-control" id="email3" placeholder="" name="email3">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group message">
                                    <label for="message3">Message*</label>
                                    <textarea class="form-control" rows="5" id="message3" placeholder="" name="message3"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <input type="submit" value="Submit" class="btn btn-default">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="trigger">
        <a href="javascript:showPreHeader()" class="triangle"><i class="fa fa-plus"></i></a>
    </div>
</div>
<!-- preheader end -->
