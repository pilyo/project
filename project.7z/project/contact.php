<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Register Consumer Complaint online in India - Hootzap</title>
    <meta name="description" content="Hootzap is a legal complaint service in India that resolves online consumer complaints and provides the right compensation . Register your complaint to solve your problem." />
    <meta name="author" content="RAWR">
    <?php include 'include/styles.php';?>
    <!-- Inline Css Here -->
    <style type="text/css"></style>
</head>

<body class="front preload">
    <!-- page wrapper start (Add "boxed" class to page-wrapper in order to enable boxed layout mode) -->
    <div class="page-wrapper">
        <!-- scrollToTop start -->
        <div class="scrollToTop"><i class="fa fa-angle-up"></i></div>
        <!-- scrollToTop end -->
        <?php include 'include/pre-header.php';?>
        <?php include 'include/header-top.php';?>
        <?php include 'include/header.php';?>
        <?php include 'include/nav.php';?>
        <?php include 'include/banner.php';?>
        <!-- ################################################
			 ########## MAIN CONTENT STARTS HERE! ###########
			 ################################################ -->
			<section class="main">

				<!-- main content wrapper start -->
				<div class="main-content-wrapper">
					<div class="container">
						<div class="row">

							<!-- main content start -->
							<section class="main-content col-md-8">
								<h3 class="title">Contact Us</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
								<div class="alert alert-success hidden" id="contactSuccess">
									<strong>Success!</strong> Your message has been sent to us.
								</div>
								<div class="alert alert-error hidden" id="contactError">
									<strong>Error!</strong> There was an error sending your message.
								</div>
								<div class="contact-form">
									<form id="contact-form" role="form">
										<div class="form-group name">
											<label for="name">Name*</label>
											<input type="text" class="form-control" id="name" name="name" placeholder="">
										</div>
										<div class="form-group email">
											<label for="email">Email*</label>
											<input type="email" class="form-control" id="email" name="email" placeholder="">
										</div>
										<div class="form-group subject">
											<label for="subject">Subject*</label>
											<input type="text" class="form-control" id="subject" name="subject" placeholder="">
										</div>
										<div class="form-group message">
											<label for="message">Message*</label>
											<textarea class="form-control" rows="6" id="message" name="message" placeholder=""></textarea>
										</div>
										<input type="submit" value="Submit" class="btn btn-default">
									</form>
								</div>
							</section>
							<!-- main content end -->

							<!-- sidebar start -->
							<aside class="sidebar col-md-4">
								<div class="side vertical-divider-left">
									<h3 class="title">Find Us</h3>
									<ul class="list">
										<li><strong> HootZap</strong></li>
										
										<li><i class="fa fa-phone pr-10"></i><abbr title="Phone"></abbr> +91-11-39595933</li>
									</ul>
									<ul class="list">
										<li><strong>Email</strong></li>
										<li><i class="fa fa-envelope pr-10"></i><a href="mailto:#">info@hootzap.com</a></li>
									</ul>
									<ul class="social-links large">
										<li><a target="_blank" href="http://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
										<li><a target="_blank" href="http://www.twitter.com"><i class="fa fa-twitter"></i></a></li>
										<li><a target="_blank" href="http://plus.google.com"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</aside>
							<!-- sidebar end -->

						</div>
					</div>
				</div>
				<!-- main content wrapper end -->

			</section>
        <!-- ################################################
			 ############ MAIN CONTENT ENDS HERE! ###########
			 ################################################  -->
        <?php include 'include/footer.php';?>
    </div>
    <!-- page wrapper end -->
    <?php include 'include/scripts.php';?>
    <!-- Inline javascript here! -->
    <script type="text/javascript">
    	
    </script>
</body>

</html>
