<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Register Consumer Complaint online in India - Hootzap</title>
    <meta name="description" content="Hootzap is a legal complaint service in India that resolves online consumer complaints and provides the right compensation . Register your complaint to solve your problem." />
    <meta name="author" content="RAWR">
    <?php include 'include/styles.php';?>
    <!-- Inline Css Here -->
    <style type="text/css"></style>
</head>

<body class="front preload">
    <!-- page wrapper start (Add "boxed" class to page-wrapper in order to enable boxed layout mode) -->
    <div class="page-wrapper">
        <!-- scrollToTop start -->
        <div class="scrollToTop"><i class="fa fa-angle-up"></i></div>
        <!-- scrollToTop end -->
        <?php include 'include/pre-header.php';?>
        <?php include 'include/header-top.php';?>
        <?php include 'include/header.php';?>
        <?php include 'include/nav.php';?>
        <?php include 'include/banner.php';?>
        <!-- ################################################
			 ########## MAIN CONTENT STARTS HERE! ###########
			 ################################################ -->
        <section class="main">
            <!-- section start -->
            <div class="section" style="padding:0 0 0 0;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="text-center">Get Your Complaints Resolved in 3 Easy Steps</h3>
                            <div class="separator"></div>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="icon-box">
                                        <div style="margin-bottom:20px"><img src="http://hootzap.com/images/unhappy.png" style="margin:auto"></div>
                                        <h4>Directly complaint.</h4>
                                        <p>Our team takes the complaint directly to the escalation team of the seller-company.</p>
                                        
                                        
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="icon-box">
                                        <div style="margin-bottom:43px"><img src="http://hootzap.com/images/file.png" style="margin:auto"></div>
                                        <h4>Send legal notice.</h4>
                                        <p>We send a well drafted legal notice to the company, Simultaneously complaint contents are posted/published on various social media and Internet Forums to seek immediate positive attention of the merchant.</p>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="icon-box">
                                        <div style="margin-bottom:20px"><img src="http://hootzap.com/images/resolve.png" style="margin:auto"></div><h4>Approaching the Consumer forum.</h4>
                                        <p>The last resort is approaching the Consumer forum when the complaint goes unattended and for that We will assist you. All you need to do is sign the documents and submit them to consumer court.</p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- section end -->
            <!-- section start -->
            <!--
            <div class="section bg-color-light">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <img class="img-responsive center-block" src="images/section-image-1.png" alt="iVega">
                        </div>
                        <div class="col-md-6">
                            <h2>HOOTZAP  Rocks!</h2>
                            <p class="space">HOOTZAP IS A DEMOCRATIC PLATFORM THAT INTERVENES TO RESOLVE CONSUMER GRIEVANCE AND PROVIDES THE RIGHT REDRESS.</p>
                            <a href="page-about.html" class="btn btn-default btn-lg">Learn More</a>
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <br>
                <div class="bg-color-gray call-to-action">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <h2 class="text-center">You Name it. We Claim it.</h2>
                            </div>
                            <div class="col-md-4 text-center">
                                <a href="#" class="btn btn-lg btn-white">File your Compalint</a>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <div class="container">
                    <h1 class="text-center">Our Services</h1>
                    <div class="separator"></div>
                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div class="row">
                        <div class="col-sm-6 col-md-4">
                            <div class="icon-box-3 icon-right clearfix object-non-visible" data-animation-effect="fadeInLeftSmall" data-effect-delay="0">
                                <i class="fa fa-desktop"></i>
                                <div class="text">
                                    <h4>100% Responsive Design</h4>
                                    <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-right clearfix object-non-visible" data-animation-effect="fadeInLeftSmall" data-effect-delay="100">
                                <i class="fa fa-bold"></i>
                                <div class="text">
                                    <h4>Bootstrap Based</h4>
                                    <p class="small">Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-right clearfix object-non-visible" data-animation-effect="fadeInLeftSmall" data-effect-delay="200">
                                <i class="fa fa-leaf"></i>
                                <div class="text">
                                    <h4>Clean &amp; powerful code</h4>
                                    <p class="small">Cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-right clearfix object-non-visible" data-animation-effect="fadeInLeftSmall" data-effect-delay="300">
                                <i class="fa fa-cog"></i>
                                <div class="text">
                                    <h4>Unlimited layouts</h4>
                                    <p class="small">Cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <img src="images/section-image-4.png" alt="ivega" class="object-non-visible center-block" data-animation-effect="fadeInDownSmall" data-effect-delay="400">
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="icon-box-3 icon-left clearfix object-non-visible" data-animation-effect="fadeInRightSmall" data-effect-delay="0">
                                <i class="fa fa-html5"></i>
                                <div class="text">
                                    <h4>HTML5/CSS3</h4>
                                    <p class="small">Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-left clearfix object-non-visible" data-animation-effect="fadeInRightSmall" data-effect-delay="100">
                                <i class="fa fa-rocket"></i>
                                <div class="text">
                                    <h4>Font Awesome Icons</h4>
                                    <p class="small">Cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-left clearfix object-non-visible" data-animation-effect="fadeInRightSmall" data-effect-delay="200">
                                <i class="fa fa-file-o"></i>
                                <div class="text">
                                    <h4> Well Documented</h4>
                                    <p class="small">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad.</p>
                                </div>
                            </div>
                            <div class="icon-box-3 icon-left clearfix object-non-visible" data-animation-effect="fadeInRightSmall" data-effect-delay="300">
                                <i class="fa fa-gift"></i>
                                <div class="text">
                                    <h4>Lot's of Goodies</h4>
                                    <p class="small">Cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- section end -->
            <!-- section start -->
            <div class="separator"></div>
            <!--
            <div class="section pb-clear" style="padding:0 0 0 0">
                <h3 class="text-center">List of Companies</h3>
                <div class="img-boxes owl-carousel carousel">
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-1.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-2.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-3.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-4.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-5.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-6.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-7.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                    <a href="portfolio-item.html" class="mask-wrapper">
                        <img src="images/portfolio-8.jpg" alt="">
                        <div class="mask">
                            <p>Lorem ipsum dolor sit amet</p>
                            <span>web desing</span>
                            <span class="triangle"><i class="fa fa-link"></i></span>
                        </div>
                    </a>
                </div>
            </div>
            -->
            <!-- section end -->

            <!-- section start -->
            <!--
            <div class="section">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="text-center">Why Choose Us</h1>
                            <div class="separator"></div>
                            <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, voluptas, obcaecati
                                <br> cumque ad voluptatibus molestiae minus architecto voluptatum provident.</p>
                            <br>
                            <div class="row">
                                <div class="col-md-6 col-md-push-6">
                                    <img class="img-responsive center-block pb object-non-visible" data-animation-effect="fadeInUpSmall" src="images/section-image-2.png" alt="iVega">
                                </div>
                                <div class="col-md-6 col-md-pull-6">
                                    <h3>Uspendisse id sem elementum condimentum lorem</h3>
                                    <p>Sed eget pulvinar quam, vel feugiat enim. Aliquam erat volutpat. Phasellus eu porta ipsum. Suspendisse aliquet imperdiet commodo. Aenean vel lacinia elit. Class aptent taciti sociosqu ad litora torquent per. Vestibulum velmo.</p>
                                    <ul class="list-triangle">
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall">Etiam sed dolor ac diam volutpat </li>
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="100">Sed eget pulvinar quam, vel feugiat enim aliquam </li>
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="200">Erat volutpat. Phasellus eu porta ipsum suspendisse aliquet imperdiet </li>
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="300">Phasellus eu porta ipsum. Suspendisse aliquet imperdiet commodo </li>
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="300">Quas voluptas obcaecati.</li>
                                        <li class="object-non-visible" data-animation-effect="fadeInUpSmall" data-effect-delay="300">aliquet imperdiet commodo.</li>
                                    </ul>
                                    <a href="page-about.html" class="btn btn-white btn-lg object-non-visible" data-animation-effect="flipInX" data-effect-delay="200">Learn More</a>
                                </div>
                            </div>
                            <br>
                            <hr>
                            <h1 class="text-center space-top">Skills &amp; Stats</h1>
                            <div class="separator"></div>
                            <p class="text-center">Incidunt, mollitia, laboriosam, officiis adipisci ipsum ipsam ab ducimus dolor
                                <br> omnis facere minus vero illo officia commodi voluptatem voluptate aliquam dicta suscipit.</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="space-top space-bottom">
                                        <h4>HTML5</h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-default" role="progressbar" data-animate-width="80%">
                                                <span class="object-non-visible" data-animation-effect="fadeInLeftBig" data-effect-delay="700">80%</span>
                                            </div>
                                        </div>
                                        <h4>CSS3</h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-default" role="progressbar" data-animate-width="90%">
                                                <span class="object-non-visible" data-animation-effect="fadeInLeftBig" data-effect-delay="700">90%</span>
                                            </div>
                                        </div>
                                        <h4>JQUERY</h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-default" role="progressbar" data-animate-width="75%">
                                                <span class="object-non-visible" data-animation-effect="fadeInLeftBig" data-effect-delay="700">75%</span>
                                            </div>
                                        </div>
                                        <h4>PHP</h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-default" role="progressbar" data-animate-width="85%">
                                                <span class="object-non-visible" data-animation-effect="fadeInLeftBig" data-effect-delay="700">85%</span>
                                            </div>
                                        </div>
                                        <h4>DESIGN</h4>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-default" role="progressbar" data-animate-width="80%">
                                                <span class="object-non-visible" data-animation-effect="fadeInLeftBig" data-effect-delay="700">80%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="stats">
                                        <div class="stat-box bt-clear">
                                            <i class="fa fa-cloud-download"></i>
                                            <h5>downloads</h5>
                                            <span data-to="1525" data-speed="3000">0</span>
                                        </div>
                                        <div class="stat-box bt-clear br-clear">
                                            <i class="fa fa-user"></i>
                                            <h5>Users</h5>
                                            <span data-to="2651" data-speed="3000">0</span>
                                        </div>
                                        <div class="stat-box">
                                            <i class="fa fa-briefcase"></i>
                                            <h5>purchases</h5>
                                            <span data-to="1320" data-speed="3000">0</span>
                                        </div>
                                        <div class="stat-box br-clear">
                                            <i class="fa fa-thumbs-o-up"></i>
                                            <h5>likes</h5>
                                            <span data-to="3509" data-speed="3000">0</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            
        </section>-->
                                <!-- blogpost start -->
                                <h3 class="text-center">Recent Complaints</h3>
                                <article class="clearfix blogpost">
                                    <div class="post-date">
                                        <span class="day">26</span>
                                        <span class="month">Jun, 2014</span>
                                    </div>
                                    <div class="blogpost-content clearfix">
                                        <header>
                                            <h3><a href="blog-post.html">Lorem ipsum dolor sit amet</a></h3>
                                            <div class="post-info">
                                                <span class="submitted">By <a href="#">John Doe</a></span>
                                                <span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
                                                <span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
                                            </div>
                                        </header>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <a href="blog-post.html" class="image-wrapper mask-wrapper">
                                                    <img src="images/gallery-9.jpg" alt="blog image">
                                                    <span class="image-label"><i class="fa fa-camera"></i></span>
                                                    <span class="mask"><span class="triangle"><i class="fa fa-link"></i></span></span>
                                                </a>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="blogpost-body">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </article>
                                <!-- blogpost end -->

                                <!-- blogpost start -->
                                <article class="clearfix blogpost">
                                    <div class="post-date">
                                        <span class="day">26</span>
                                        <span class="month">Jun, 2014</span>
                                    </div>
                                    <div class="blogpost-content clearfix">
                                        <header>
                                            <h2><a href="blog-post.html">Post with embed youtube video</a></h2>
                                            <div class="post-info">
                                                <span class="submitted">By <a href="#">John Doe</a></span>
                                                <span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
                                                <span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
                                            </div>
                                        </header>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="mask-wrapper">
                                                    <div class="responsive-iframe">
                                                        <iframe src="//www.youtube.com/embed/v1uyQZNg2vE" allowfullscreen></iframe>
                                                    </div>
                                                    <div class="image-label"><i class="fa fa-video-camera"></i></div>
                                                </div> 
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="blogpost-body">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </article>
                                <!-- blogpost end -->

                                <!-- blogpost start -->
                                <article class="clearfix blogpost">
                                    <div class="post-date">
                                        <span class="day">26</span>
                                        <span class="month">Jun, 2014</span>
                                    </div>
                                    <div class="blogpost-content clearfix">
                                        <header>
                                            <h2><a href="blog-post.html">Post with embed vimeo video</a></h2>
                                            <div class="post-info">
                                                <span class="submitted">By <a href="#">John Doe</a></span>
                                                <span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
                                                <span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
                                            </div>
                                        </header>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="mask-wrapper">
                                                    <div class="responsive-iframe">
                                                        <iframe src="//player.vimeo.com/video/29198414?byline=0&amp;portrait=0" allowfullscreen></iframe> <p><a href="http://vimeo.com/29198414">Introducing Vimeo Music Store</a> from <a href="http://vimeo.com/staff">Vimeo Staff</a> on <a href="https://vimeo.com">Vimeo</a>.</p>
                                                    </div>
                                                    <div class="image-label"><i class="fa fa-video-camera"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="blogpost-body">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </article>
                                <!-- blogpost end -->

                                <!-- blogpost start -->
                                <article class="clearfix blogpost">
                                    <div class="post-date">
                                        <span class="day">26</span>
                                        <span class="month">Jun, 2014</span>
                                    </div>
                                    <div class="blogpost-content clearfix">
                                        <header>
                                            <h2><a href="blog-post.html">Post with embed audio</a></h2>
                                            <div class="post-info">
                                                <span class="submitted">By <a href="#">John Doe</a></span>
                                                <span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
                                                <span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
                                            </div>
                                        </header>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="mask-wrapper">
                                                    <div class="audio-wrapper">
                                                        <iframe height="166" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/106329682&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
                                                    </div>
                                                    <div class="image-label"><i class="fa fa-soundcloud"></i></div>
                                                </div>   
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="blogpost-body">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </article>
                                <!-- blogpost end -->

                                <!-- blogpost start -->
                                <article class="clearfix blogpost">
                                    <div class="post-date">
                                        <span class="day">26</span>
                                        <span class="month">Jun, 2014</span>
                                    </div>
                                    <div class="blogpost-content clearfix">
                                        <header>
                                            <h2><a href="blog-post.html">Post without image</a></h2>
                                            <div class="post-info">
                                                <span class="submitted">By <a href="#">John Doe</a></span>
                                                <span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
                                                <span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
                                            </div>
                                        </header>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="blogpost-body">
                                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </article>
                                <!-- blogpost end -->
                                <div style="text-align: center"><a href="#" class="btn btn-default">More Complaints</a></div>
                                
        <!-- section end -->
        <!-- ################################################
			 ############ MAIN CONTENT ENDS HERE! ###########
			 ################################################  -->
        <?php include 'include/footer.php';?>
    </div>
    <!-- page wrapper end -->
    <?php include 'include/scripts.php';?>
    <!-- Inline javascript here! -->
    <script type="text/javascript">
    	
    </script>
</body>

</html>
