<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Blog</title>
    <meta name="description" content="Hootzap is a legal complaint service in India that resolves online consumer complaints and provides the right compensation . Register your complaint to solve your problem." />
    <meta name="author" content="RAWR">
    <?php include 'include/styles.php';?>
    <!-- Inline Css Here -->
    <style type="text/css"></style>
</head>

<body class="front preload">
    <!-- page wrapper start (Add "boxed" class to page-wrapper in order to enable boxed layout mode) -->
    <div class="page-wrapper">
        <!-- scrollToTop start -->
        <div class="scrollToTop"><i class="fa fa-angle-up"></i></div>
        <!-- scrollToTop end -->
        <?php include 'include/pre-header.php';?>
        <?php include 'include/header-top.php';?>
        <?php include 'include/header.php';?>
        <?php include 'include/nav.php';?>
        <?php include 'include/banner.php';?>		<section class="main">

				<!-- page intro start -->
				<div class="page-intro">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<h1 class="page-title">Blog</h1>
							</div>
							<div class="col-md-4">
								<div class="breadcrumb-wrapper">
									<ol class="breadcrumb">
										<li><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
										<li class="active">Blog</li>
									</ol>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- page intro end -->

				<!-- main content wrapper start -->
				<div class="main-content-wrapper">
					<div class="container">
						<div class="row">

							<!-- main content start -->
							<section class="main-content col-md-8">

								<!-- blogpost start -->
								<article class="clearfix blogpost">
									<div class="post-date">
										<span class="day">26</span>
										<span class="month">Jun, 2014</span>
									</div>
									<div class="blogpost-content clearfix">
										<header>
											<h2><a href="blog-post.html">Lorem ipsum dolor sit amet</a></h2>
											<div class="post-info">
												<span class="submitted">By <a href="#">John Doe</a></span>
												<span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
												<span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
											</div>
										</header>
										<div class="row">
											<div class="col-sm-6">
												<a href="blog-post.html" class="image-wrapper mask-wrapper">
													<img src="images/blog-1.jpg" alt="blog image">
													<span class="image-label"><i class="fa fa-camera"></i></span>
													<span class="mask"><span class="triangle"><i class="fa fa-link"></i></span></span>
												</a>          
											</div>
											<div class="col-sm-6">
												<div class="blogpost-body">
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
												</div>
											</div>
										</div>
										<a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
									</div>
								</article>
								<!-- blogpost end -->

								<!-- blogpost start -->
								<article class="clearfix blogpost">
									<div class="post-date">
										<span class="day">26</span>
										<span class="month">Jun, 2014</span>
									</div>
									<div class="blogpost-content clearfix">
										<header>
											<h2><a href="blog-post.html">Post with embed youtube video</a></h2>
											<div class="post-info">
												<span class="submitted">By <a href="#">John Doe</a></span>
												<span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
												<span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
											</div>
										</header>
										<div class="row">
											<div class="col-sm-6">
												<div class="mask-wrapper">
													<div class="responsive-iframe">
														<iframe src="//www.youtube.com/embed/v1uyQZNg2vE" allowfullscreen></iframe>
													</div>
													<div class="image-label"><i class="fa fa-video-camera"></i></div>
												</div> 
											</div>
											<div class="col-sm-6">
												<div class="blogpost-body">
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
												</div>
											</div>
										</div>
										<a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
									</div>
								</article>
								<!-- blogpost end -->

								<!-- blogpost start -->
								<article class="clearfix blogpost">
									<div class="post-date">
										<span class="day">26</span>
										<span class="month">Jun, 2014</span>
									</div>
									<div class="blogpost-content clearfix">
										<header>
											<h2><a href="blog-post.html">Post with embed vimeo video</a></h2>
											<div class="post-info">
												<span class="submitted">By <a href="#">John Doe</a></span>
												<span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
												<span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
											</div>
										</header>
										<div class="row">
											<div class="col-sm-6">
												<div class="mask-wrapper">
													<div class="responsive-iframe">
														<iframe src="//player.vimeo.com/video/29198414?byline=0&amp;portrait=0" allowfullscreen></iframe> <p><a href="http://vimeo.com/29198414">Introducing Vimeo Music Store</a> from <a href="http://vimeo.com/staff">Vimeo Staff</a> on <a href="https://vimeo.com">Vimeo</a>.</p>
													</div>
													<div class="image-label"><i class="fa fa-video-camera"></i></div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="blogpost-body">
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
												</div>
											</div>
										</div>
										<a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
									</div>
								</article>
								<!-- blogpost end -->

								<!-- blogpost start -->
								<article class="clearfix blogpost">
									<div class="post-date">
										<span class="day">26</span>
										<span class="month">Jun, 2014</span>
									</div>
									<div class="blogpost-content clearfix">
										<header>
											<h2><a href="blog-post.html">Post with embed audio</a></h2>
											<div class="post-info">
												<span class="submitted">By <a href="#">John Doe</a></span>
												<span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
												<span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
											</div>
										</header>
										<div class="row">
											<div class="col-sm-6">
												<div class="mask-wrapper">
													<div class="audio-wrapper">
														<iframe height="166" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/106329682&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false"></iframe>
													</div>
													<div class="image-label"><i class="fa fa-soundcloud"></i></div>
												</div>   
											</div>
											<div class="col-sm-6">
												<div class="blogpost-body">
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
												</div>
											</div>
										</div>
										<a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
									</div>
								</article>
								<!-- blogpost end -->

								<!-- blogpost start -->
								<article class="clearfix blogpost">
									<div class="post-date">
										<span class="day">26</span>
										<span class="month">Jun, 2014</span>
									</div>
									<div class="blogpost-content clearfix">
										<header>
											<h2><a href="blog-post.html">Post without image</a></h2>
											<div class="post-info">
												<span class="submitted">By <a href="#">John Doe</a></span>
												<span class="comments-count"><i class="fa fa-comments-o"></i> <a href="#">63 comments</a></span>
												<span class="tags"><i class="fa fa-tags"></i> <a href="#">tag</a> | <a href="#">tag-2</a> | <a href="#">tag-3</a></span>
											</div>
										</header>
										<div class="row">
											<div class="col-sm-12">
												<div class="blogpost-body">
													<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex, eligendi cum officiis sint eveniet omnis eius quo. Et iusto eos dolor ratione nesciunt praesentium eveniet distinctio repellat. Quas, soluta, ipsam.</p>
												</div>
											</div>
										</div>
										<a href="blog-post.html" class="btn btn-default more pull-right">Read more <i class="fa fa-angle-double-right"></i></a>
									</div>
								</article>
								<!-- blogpost end -->

								<!-- pagination start -->
								<ul class="pagination">
									<li><a href="#">«</a></li>
									<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
									<li><a href="#">2</a></li>
									<li><a href="#">3</a></li>
									<li><a href="#">4</a></li>
									<li><a href="#">5</a></li>
									<li><a href="#">»</a></li>
								</ul>
								<!-- pagination end -->

							</section>
							<!-- main content end -->

							<!-- sidebar start -->
							<aside class="sidebar col-md-3 col-md-offset-1">
								<div class="block clearfix">
									<h3>Sidebar menu</h3>
									<nav>
										<ul class="nav nav-pills nav-stacked">
											<li><a href="index.php">Home</a></li>
											<li class="active"><a href="blog.php">Blog</a></li>
											<li><a href="page-about.html">About</a></li>
											<li><a href="contact.php">Contact</a></li>
										</ul>
									</nav>
								</div>
								<div class="block clearfix">
									<h3>Latest tweets</h3>
									<ul class="tweets">
										<li>
											<i class="fa fa-twitter"></i>
											<p><a href="#">@lorem</a> ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt <a href="#">http://t.co/dzLEYGeEH9</a>.</p><span>16 hours ago</span>
										</li>
										<li>
											<i class="fa fa-twitter"></i>
											<p><a href="#">@lorem</a> ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt <a href="#">http://t.co/dzLEYGeEH9</a>.</p><span>16 hours ago</span>
										</li>
									</ul>
								</div>
								<!--
								<div class="block clearfix">
									<h3>Testimonial</h3>
									<ul class="testimonials">
										<li>
											<i class="fa blockquote"></i>
											<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt.</p><span class="name">- John doe</span><a href="#" class="company"> Company</a>
										</li>
										<li>
											<i class="fa blockquote"></i>
											<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, aliquid, et molestias nesciunt.</p><span class="name">- John doe</span><a href="#" class="company"> Company</a>
										</li>
									</ul>
								</div> 

								<div class="block clearfix">
									<h3>Portfolio</h3>
									<div class="gallery row">
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-1.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-2.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-3.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-4.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-5.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
										<div class="gallery-item col-xs-4">
											<a href="portfolio-item.html" class="mask-wrapper">
												<img src="images/gallery-6.jpg" alt="">
												<span class="mask"><span class="small triangle"><i class="fa fa-link"></i></span></span>
											</a>
										</div>
									</div>
								</div>-->
								<div class="block">
									<h3>Tags</h3>
									<div class="tags-cloud">
										<div class="tag">
											<a href="#">energy</a>
										</div>
										<div class="tag">
											<a href="#">business</a>
										</div>
										<div class="tag">
											<a href="#">food</a>
										</div>
										<div class="tag">
											<a href="#">fashion</a>
										</div>
										<div class="tag">
											<a href="#">finance</a>
										</div>
										<div class="tag">
											<a href="#">culture</a>
										</div>
										<div class="tag">
											<a href="#">health</a>
										</div>
										<div class="tag">
											<a href="#">sports</a>
										</div>
										<div class="tag">
											<a href="#">life style</a>
										</div>
										<div class="tag">
											<a href="#">books</a>
										</div>
									</div>
								</div>
								<div class="block bb-clear clearfix">
									<form role="search">
										<div class="form-group search">
											<input type="text" class="form-control" placeholder="Search">
										</div>
									</form>
								</div>
							</aside>
							<!-- sidebar end -->

						</div>
					</div>
				</div>
				<!-- main content wrapper end -->

			</section>
			<!-- main end -->

        <!-- ################################################
			 ############ MAIN CONTENT ENDS HERE! ###########
			 ################################################  -->
        <?php include 'include/footer.php';?>
    </div>
    <!-- page wrapper end -->
    <?php include 'include/scripts.php';?>
    <!-- Inline javascript here! -->
    <script type="text/javascript">
    	
    </script>
</body>

</html>
